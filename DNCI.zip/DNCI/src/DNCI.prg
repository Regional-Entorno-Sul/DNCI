Function main()

set color to bg+/
cls

@ 1,0 say "|-----------------------------------------------------------|"
@ 2,0 say "|DNCI.exe - versao beta - 26/10/2026                        |"
@ 3,0 say "|Regional Entorno Sul                                       |"
@ 4,0 say "|-----------------------------------------------------------|"

set color to g+/
@ 5,0 say "Descompacta o(s) arquivo(s) de Dengue..."

nArraySize := ADir( "c:\dnci\dbf\dengue\*.zip" )
aName := Array( nArraySize )
? aName
ADir( ( "c:\dnci\dbf\dengue\*.zip" ),aName )
for f = 1 to nArraySize
hb_UnzipFile( ( "c:\dnci\dbf\dengue\" ) + aName[f] )
next

@ 6,0 say "Faz a fusao dos arquivos de Dengue (se houver mais de um.)..."

nArraySize2 := ADir( ( "c:\dnci\dbf\dengue\*.dbf" ) )
aName2 := Array( nArraySize2 )
ADir( ( "c:\dnci\dbf\dengue\*.dbf" ), aName2 )

copy file "c:\dnci\mod\dengon_model.dbf" to "c:\dnci\temp\dengon_model.dbf"

use "c:\dnci\temp\dengon_model.dbf"

for f = 1 to nArraySize2
append from ( "c:\dnci\dbf\dengue\" + aName2[f] )
next

close

@ 7,0 say "Descompacta o(s) arquivo(s) de Chikungunya..."

nArraySize := ADir( "c:\dnci\dbf\chik\*.zip" )
aName := Array( nArraySize )
? aName
ADir( ( "c:\dnci\dbf\chik\*.zip" ),aName )
for f = 1 to nArraySize
hb_UnzipFile( ( "c:\dnci\dbf\chik\" ) + aName[f] )
next

@ 8,0 say "Faz a fusao dos arquivos de Chikungunya (se houver mais de um.)..."

nArraySize2 := ADir( ( "c:\dnci\dbf\chik\*.dbf" ) )
aName2 := Array( nArraySize2 )
ADir( ( "c:\dnci\dbf\chik\*.dbf" ), aName2 )

copy file "c:\dnci\mod\chikon_model.dbf" to "c:\dnci\temp\chikon_model.dbf"

use "c:\dnci\temp\chikon_model.dbf"

for f = 1 to nArraySize2
append from ( "c:\dnci\dbf\chik\" + aName2[f] )
next

close

@ 9,0 say "Preparando arquivo nindinet.dbf para processamento..."
copy file "c:\dnci\dbf\nindinet\nindinet.dbf" to "c:\dnci\temp\nindi_dnci.dbf"

use "c:\dnci\temp\nindi_dnci.dbf"

@ 10,0 say "Filtrando no arquivo nindi_dnci.dbf os agravos de interesse..."

do while .not. eof()

*A00.9 - Colera
*A92.8 - Zika
*A95.9 - Febre Amarela
*A92.3 - Febre do Nilo
*J11 - Influenza humana por novo subtipo (pandemico)
*A96.9 - Febre hemorragica por arenavirus, nao especificada
*B54 - Malaria
*A20.9 - Peste
*B09 - Doencas exantematicas
*A80.9 - Paralisia flacida aguda - poliomielite
*A82.9 - Raiva humana

replace tp_not with "x" for id_agravo = "A00.9" .or. id_agravo = "A92.8" .or. ;
id_agravo = "A95.9" .or. id_agravo = "A92.3" .or. id_agravo = "J11"  .or. ;
id_agravo = "A96.9" .or. id_agravo = "B54" .or. id_agravo = "A20.9" .or. id_agravo = "B09" .or. ;
id_agravo = "A80.9" .or. id_agravo = "A82.9"

skip

enddo

close

@ 11,0 say "Deixa no arquivo nindi_dnci.dbf apenas registros com encerramento pendente..."

use "c:\dnci\temp\nindi_dnci.dbf"
delete for tp_not <> "x"
pack
close

return