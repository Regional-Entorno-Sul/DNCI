Function main()

set century on
set date to british
set color to bg+/
cls

@ 1,0 say "|-----------------------------------------------------------------|"
@ 2,0 say "|DNCI.exe - versao beta - 26/10/2026                              |"
@ 3,0 say "|Regional Entorno Sul                                             |"
@ 4,0 say "|https://github.com/Regional-Entorno-Sul/DNCI                     |"
@ 5,0 say "|Gera uma planilha com as notificacoes que servem de base         |"
@ 6,0 say "|para o calculo do indicador do DNCI para fins de auditoria       |"
@ 7,0 say "|e tambem gera uma planilha com as notificacoes inconsistentes.   |"
@ 8,0 say "|-----------------------------------------------------------------|"

set color to g+/
@ 9,0 say "Descompacta o(s) arquivo(s) de Dengue..."

nArraySize := ADir( "c:\dnci\dbf\dengue\*.zip" )
aName := Array( nArraySize )
? aName
ADir( ( "c:\dnci\dbf\dengue\*.zip" ),aName )
for f = 1 to nArraySize
hb_UnzipFile( ( "c:\dnci\dbf\dengue\" ) + aName[f] )
next

@ 10,0 say "Faz a fusao dos arquivos de Dengue (se houver mais de um.)..."

nArraySize2 := ADir( ( "c:\dnci\dbf\dengue\*.dbf" ) )
aName2 := Array( nArraySize2 )
ADir( ( "c:\dnci\dbf\dengue\*.dbf" ), aName2 )

copy file "c:\dnci\mod\dengon_model.dbf" to "c:\dnci\temp\dengon_model.dbf"

use "c:\dnci\temp\dengon_model.dbf"

for f = 1 to nArraySize2
append from ( "c:\dnci\dbf\dengue\" + aName2[f] )
next

close

@11,0 say "Descompacta o(s) arquivo(s) de Chikungunya..."

nArraySize := ADir( "c:\dnci\dbf\chik\*.zip" )
aName := Array( nArraySize )
? aName
ADir( ( "c:\dnci\dbf\chik\*.zip" ),aName )
for f = 1 to nArraySize
hb_UnzipFile( ( "c:\dnci\dbf\chik\" ) + aName[f] )
next

@ 12,0 say "Faz a fusao dos arquivos de Chikungunya (se houver mais de um.)..."

nArraySize2 := ADir( ( "c:\dnci\dbf\chik\*.dbf" ) )
aName2 := Array( nArraySize2 )
ADir( ( "c:\dnci\dbf\chik\*.dbf" ), aName2 )

copy file "c:\dnci\mod\chikon_model.dbf" to "c:\dnci\temp\chikon_model.dbf"

use "c:\dnci\temp\chikon_model.dbf"

for f = 1 to nArraySize2
append from ( "c:\dnci\dbf\chik\" + aName2[f] )
next

close

@ 13,0 say "Preparando arquivo nindinet.dbf para processamento..."
copy file "c:\dnci\dbf\nindinet\nindinet.dbf" to "c:\dnci\temp\nindi_dnci.dbf"

use "c:\dnci\temp\nindi_dnci.dbf"

@ 14,0 say "Filtrando no arquivo 'nindi_dnci.dbf' os agravos de interesse..."
do while .not. eof()

*A00.9 - Colera
*A92.8 - Zika
*A95.9 - Febre Amarela
*A92.3 - Febre do Nilo
*J11 - Influenza humana por novo subtipo (pandemico)
*A96.9 - Febre hemorragica por arenavirus, nao especificada
*B54 - Malaria
*A20.9 - Peste
*B09 - Doencas exantematicas
*A80.9 - Paralisia flacida aguda - poliomielite
*A82.9 - Raiva humana

replace tp_not with "x" for id_agravo = "A009" .or. id_agravo = "A928" .or. ;
id_agravo = "A959" .or. id_agravo = "A923" .or. id_agravo = "J11"  .or. ;
id_agravo = "A969" .or. id_agravo = "B54" .or. id_agravo = "A209" .or. id_agravo = "B09" .or. ;
id_agravo = "A809" .or. id_agravo = "A829"
skip

enddo

close

use "c:\dnci\temp\nindi_dnci.dbf"
delete for tp_not <> "x"
pack
close

@ 15,0 say "Filtrando no arquivo 'nindi_dnci.dbf' os municipios de interesse..."
copy file "c:\dnci\mod\list_muns.dbf" to "c:\dnci\set\list_muns.dbf"

use "c:\dnci\set\list_muns.dbf"
zap
append from "c:\dnci\set\list_muns.txt" delimited with '"'
close

	  public aArray_mun_list := {}
	  use "c:\dnci\set\list_muns.dbf"
      nRecs := reccount()
      FOR x := 1 TO nRecs
	  AAdd( aArray_mun_list, {alltrim(cod_munres)} )
	  skip
	  NEXT
	  close

public nTimes
nTimes := len(aArray_mun_list)

for n = 1 to nTimes
use "c:\dnci\temp\nindi_dnci.dbf"
do while .not. eof()
replace id_regiona with "x" for alltrim( id_mn_resi ) = alltrim( aArray_mun_list[n,1] )
skip
enddo

close

next

use "c:\dnci\temp\nindi_dnci.dbf"
delete for id_regiona <> "x" 
pack
close

@ 16,0 say "Filtrando os registros de Zika virus..."
use "c:\dnci\temp\nindi_dnci.dbf"
delete for alltrim( id_agravo ) = "A928" .and. evolucao <> "4" 
pack
close

@ 17,0 say "Filtrando o arquivo de Dengue..." 
use "c:\dnci\temp\dengon_model.dbf"
delete for evolucao <> "2"
pack
close

@ 18,0 say "Filtrando o arquivo de Chikungunya..."
use "c:\dnci\temp\chikon_model.dbf"
delete for evolucao <> "4"
pack
close

@ 19,0 say "Renomeando os arquivos com os registros remanescentes..."
rename "c:\dnci\temp\dengon_model.dbf" to "c:\dnci\temp\dengon_model_filter1.dbf"
rename "c:\dnci\temp\chikon_model.dbf" to "c:\dnci\temp\chikon_model_filter1.dbf"
rename "c:\dnci\temp\nindi_dnci.dbf" to "c:\dnci\temp\nindi_dnci_filter1.dbf"

@ 20,0 say "Criando arquivo simplificado para colocar os registros encontrados..."

cMolde1 := ( "c:\dnci\temp\molde1.dbf" )
cMolde2 := ( "c:\dnci\temp\molde2.dbf" )
cMolde3 := ( "c:\dnci\temp\molde3.dbf" )
cMolde4 := ( "c:\dnci\temp\molde4.dbf" )

aStruct := { { "nu_notific","C",7,0 }, ; //1
			 { "id_agravo","C",4,0 }, ; //2
			 { "dt_notific","D",10,0 }, ; //3
			 { "id_municip","C",6,0 }, ; //4
			 { "nm_pacient","C",70,0 }, ; //5
			 { "dt_nasc","D",10,0 }, ; //6
			 { "nm_mae_pac","C",60,0 }, ; //7
			 { "id_mn_resi","C",6,0 }, ; //8
			 { "evolucao","C",1,0 }, ; //9
			 { "dt_encerra","D",10,0 }} //10
			 dbcreate (( cMolde1 ),aStruct )

use ( cMolde1 )
copy to ( cMolde2 )

* Acrescenta campos novos.
				use ( cMolde2 ) new
				aStruct2 := dbStruct( cMolde2 )
				AADD(aStruct2, { "days","N",5,0 }) //11
				
				dbCreate( (cMolde3 ) , aStruct2 )
close ( cMolde1 )

rename (cMolde3) to (cMolde4)
rename (cMolde4) to "c:\dnci\temp\light_nindi_filter1.dbf"

@ 21,0 say "Passando os regitros para o arquivo simplificado..."
use "c:\dnci\temp\light_nindi_filter1.dbf"
append from "c:\dnci\temp\nindi_dnci_filter1.dbf"
close






return