Function main()

set century on
set date to british
set decimals to 2
set color to bg+/
cls

@ 1,0 say "|-----------------------------------------------------------------|"
@ 2,0 say "|DNCI.exe - versao release candidate (RC) - 05/11/2026            |"
@ 3,0 say "|Regional Entorno Sul                                             |"
@ 4,0 say "|https://github.com/Regional-Entorno-Sul/DNCI                     |"
@ 5,0 say "|Gera uma planilha com as notificacoes que servem de base         |"
@ 6,0 say "|para o calculo do indicador do DNCI para fins de auditoria       |"
@ 7,0 say "|e tambem gera uma planilha com as notificacoes inconsistentes.   |"
@ 8,0 say "|-----------------------------------------------------------------|"

set color to g+/

@ 9,0 say "Exclui arquivos remanescentes do diretorio 'temp'..."
__run( "echo off & del /F /Q c:\dnci\temp\*.dbf" )

@ 10,0 say "Descompacta o(s) arquivo(s) de Dengue..."

nArraySize := ADir( "c:\dnci\dbf\dengue\*.zip" )
aName := Array( nArraySize )
? aName
ADir( ( "c:\dnci\dbf\dengue\*.zip" ),aName )
for f = 1 to nArraySize
hb_UnzipFile( ( "c:\dnci\dbf\dengue\" ) + aName[f] )
next

@ 11,0 say "Faz a fusao dos arquivos de Dengue (se houver mais de um.)..."

nArraySize2 := ADir( ( "c:\dnci\dbf\dengue\*.dbf" ) )
aName2 := Array( nArraySize2 )
ADir( ( "c:\dnci\dbf\dengue\*.dbf" ), aName2 )

copy file "c:\dnci\mod\dengon_model.dbf" to "c:\dnci\temp\dengon_model.dbf"

use "c:\dnci\temp\dengon_model.dbf"

for f = 1 to nArraySize2
append from ( "c:\dnci\dbf\dengue\" + aName2[f] )
next

close

@12,0 say "Descompacta o(s) arquivo(s) de Chikungunya..."

nArraySize := ADir( "c:\dnci\dbf\chik\*.zip" )
aName := Array( nArraySize )
? aName
ADir( ( "c:\dnci\dbf\chik\*.zip" ),aName )
for f = 1 to nArraySize
hb_UnzipFile( ( "c:\dnci\dbf\chik\" ) + aName[f] )
next

@ 13,0 say "Faz a fusao dos arquivos de Chikungunya (se houver mais de um.)..."

nArraySize2 := ADir( ( "c:\dnci\dbf\chik\*.dbf" ) )
aName2 := Array( nArraySize2 )
ADir( ( "c:\dnci\dbf\chik\*.dbf" ), aName2 )

copy file "c:\dnci\mod\chikon_model.dbf" to "c:\dnci\temp\chikon_model.dbf"

use "c:\dnci\temp\chikon_model.dbf"

for f = 1 to nArraySize2
append from ( "c:\dnci\dbf\chik\" + aName2[f] )
next

close

@ 14,0 say "Preparando arquivo nindinet.dbf para processamento..."
copy file "c:\dnci\dbf\nindinet\nindinet.dbf" to "c:\dnci\temp\nindi_dnci.dbf"

use "c:\dnci\temp\nindi_dnci.dbf"

@ 15,0 say "Filtrando no arquivo 'nindi_dnci.dbf' os agravos de interesse..."
do while .not. eof()

*A00.9 - Colera
*A92.8 - Zika
*A95.9 - Febre Amarela
*A92.3 - Febre do Nilo
*J11 - Influenza humana por novo subtipo (pandemico)
*A96.9 - Febre hemorragica por arenavirus, nao especificada
*B54 - Malaria
*A20.9 - Peste
*B09 - Doencas exantematicas
*A80.9 - Paralisia flacida aguda - poliomielite
*A82.9 - Raiva humana

replace tp_not with "x" for id_agravo = "A009" .or. id_agravo = "A928" .or. ;
id_agravo = "A959" .or. id_agravo = "A923" .or. id_agravo = "J11"  .or. ;
id_agravo = "A969" .or. id_agravo = "B54" .or. id_agravo = "A209" .or. id_agravo = "B09" .or. ;
id_agravo = "A809" .or. id_agravo = "A829"
skip

enddo

close

use "c:\dnci\temp\nindi_dnci.dbf"
delete for tp_not <> "x"
pack
close

@ 16,0 say "Filtrando no arquivo 'nindi_dnci.dbf' os municipios de interesse..."
copy file "c:\dnci\mod\list_muns.dbf" to "c:\dnci\set\list_muns.dbf"

use "c:\dnci\set\list_muns.dbf"
zap
append from "c:\dnci\set\list_muns.txt" delimited with '"'
close

	  public aArray_mun_list := {}
	  use "c:\dnci\set\list_muns.dbf"
      nRecs := reccount()
      FOR x := 1 TO nRecs
	  AAdd( aArray_mun_list, {alltrim(cod_munres)} )
	  skip
	  NEXT
	  close

public nTimes
nTimes := len(aArray_mun_list)

for n = 1 to nTimes
use "c:\dnci\temp\nindi_dnci.dbf"
do while .not. eof()
replace id_regiona with "x" for alltrim( id_mn_resi ) = alltrim( aArray_mun_list[n,1] )
skip
enddo

close

next

use "c:\dnci\temp\nindi_dnci.dbf"
delete for id_regiona <> "x" 
pack
close

@ 17,0 say "Filtrando os registros de Zika virus..."
use "c:\dnci\temp\nindi_dnci.dbf"
delete for alltrim( id_agravo ) = "A928" .and. evolucao <> "4" 
pack
close

@ 18,0 say "Filtrando o arquivo de Dengue..." 
use "c:\dnci\temp\dengon_model.dbf"
delete for evolucao <> "2"
pack
close

@ 19,0 say "Filtrando o arquivo de Chikungunya..."
use "c:\dnci\temp\chikon_model.dbf"
delete for evolucao <> "4"
pack
close

@ 20,0 say "Renomeando os arquivos com os registros remanescentes..."
rename "c:\dnci\temp\dengon_model.dbf" to "c:\dnci\temp\dengon_model_filter1.dbf"
rename "c:\dnci\temp\chikon_model.dbf" to "c:\dnci\temp\chikon_model_filter1.dbf"
rename "c:\dnci\temp\nindi_dnci.dbf" to "c:\dnci\temp\nindi_dnci_filter1.dbf"

@ 21,0 say "Criando arquivo simplificado para colocar os registros encontrados..."

cMolde1 := ( "c:\dnci\temp\molde1.dbf" )
cMolde2 := ( "c:\dnci\temp\molde2.dbf" )
cMolde3 := ( "c:\dnci\temp\molde3.dbf" )
cMolde4 := ( "c:\dnci\temp\molde4.dbf" )

aStruct := { { "nu_notific","C",7,0 }, ; //1
			 { "id_agravo","C",4,0 }, ; //2
			 { "dt_notific","D",10,0 }, ; //3
			 { "id_municip","C",6,0 }, ; //4
			 { "nm_pacient","C",70,0 }, ; //5
			 { "dt_nasc","D",10,0 }, ; //6
			 { "nm_mae_pac","C",60,0 }, ; //7
			 { "id_mn_resi","C",6,0 }, ; //8
			 { "evolucao","C",1,0 }, ; //9
			 { "dt_encerra","D",10,0 }} //10
			 dbcreate (( cMolde1 ),aStruct )

use ( cMolde1 )
copy to ( cMolde2 )

* Acrescenta campos novos.
				use ( cMolde2 ) new
				aStruct2 := dbStruct( cMolde2 )
				AADD(aStruct2, { "days","N",5,0 }) //11
				AADD(aStruct2, { "oport","C",1,0 }) //12
				
				dbCreate( (cMolde3 ) , aStruct2 )
close ( cMolde1 )

rename (cMolde3) to (cMolde4)
rename (cMolde4) to "c:\dnci\temp\light_nindi_filter1.dbf"
copy file "c:\dnci\temp\light_nindi_filter1.dbf" to "c:\dnci\temp\light_dengue_filter1.dbf"
copy file "c:\dnci\temp\light_nindi_filter1.dbf" to "c:\dnci\temp\light_chik_filter1.dbf"

@ 22,0 say "Passando os regitros para o arquivo simplificado..."
use "c:\dnci\temp\light_nindi_filter1.dbf"
append from "c:\dnci\temp\nindi_dnci_filter1.dbf"
close

use "c:\dnci\temp\light_dengue_filter1.dbf"
append from "c:\dnci\temp\dengon_model_filter1.dbf"
close

use "c:\dnci\temp\light_chik_filter1.dbf"
append from "c:\dnci\temp\chikon_model_filter1.dbf"
close

@ 23,0 say "Calculando a diferenca entre a data de encerramento e a data de notificacao..."
use "c:\dnci\temp\light_nindi_filter1.dbf"
do while .not. eof()
replace days with ( dt_encerra - dt_notific )
skip
enddo
close

use "c:\dnci\temp\light_dengue_filter1.dbf"
do while .not. eof()
replace days with ( dt_encerra - dt_notific )
skip
enddo
close

use "c:\dnci\temp\light_chik_filter1.dbf"
do while .not. eof()
replace days with ( dt_encerra - dt_notific )
skip
enddo
close

@ 24,0 say "Marcando os registros com encerramento oportuno"
use "c:\dnci\temp\light_nindi_filter1.dbf"
do while .not. eof()
replace oport with "x" for days <= 60
skip
enddo
close

use "c:\dnci\temp\light_dengue_filter1.dbf"
do while .not. eof()
replace oport with "x" for days <= 60
skip
enddo
close

use "c:\dnci\temp\light_chik_filter1.dbf"
do while .not. eof()
replace oport with "x" for days <= 60
skip
enddo
close

@ 25,0 say "Criando arquivo para comportar o calculo do indicador DNCI."

cMolde10 := ( "c:\dnci\temp\molde10.dbf" )

aStruct := { { "cod_munres","C",8,0 }, ; //1
			 { "munic_name","C",70,0 }, ; //2			 			 
			 { "notifics","N",8,0 }, ; //3
			 { "oportunas","N",8,0 }, ; //4
			 { "enc_oport","N",8,2 }} //5
			 dbcreate (( cMolde10 ),aStruct )

rename ( cMolde10 ) to "c:\dnci\temp\dnci_index.dbf"

use "c:\dnci\temp\dnci_index.dbf"
append from "c:\dnci\set\list_muns.dbf"
close

@ 26,0 say "Povoa o arquivo 'dnci_index.dbf' e calcula o indice DNCI."

public nRecs, nNotifics_nindi, nOportunas_nindi, nEnc_Oport
public nNotifics_deng, nOportunas_deng
public nNotifics_chik, nOportunas_chik
public nNotifics_tot, nOportunas_tot

use "c:\dnci\temp\dnci_index.dbf"
nRecs := reccount()
close

? "---------------------------------------------------------------------------"
? "Ordem | municipio de residencia | Tot.not.DNCI | Tot.not.oportunas"

for n := 1 to nRecs

use "c:\dnci\temp\light_nindi_filter1.dbf"
count to nNotifics_nindi for id_mn_resi = aArray_mun_list[n,1]
count to nOportunas_nindi for id_mn_resi = aArray_mun_list[n,1] .and. oport = "x"
close

use "c:\dnci\temp\light_dengue_filter1.dbf"
count to nNotifics_deng for id_mn_resi = aArray_mun_list[n,1]
count to nOportunas_deng for id_mn_resi = aArray_mun_list[n,1] .and. oport = "x"
close

use "c:\dnci\temp\light_chik_filter1.dbf"
count to nNotifics_chik for id_mn_resi = aArray_mun_list[n,1]
count to nOportunas_chik for id_mn_resi = aArray_mun_list[n,1] .and. oport = "x"
close

nNotifics_tot := nNotifics_nindi + nNotifics_deng + nNotifics_chik
nOportunas_tot := nOportunas_nindi + nOportunas_deng + nOportunas_chik

? alltrim( str(n) ), aArray_mun_list[n,1], str( nNotifics_tot ), str ( nOportunas_tot )

use "c:\dnci\temp\dnci_index.dbf"
replace notifics with nNotifics_tot for cod_munres = aArray_mun_list[n,1]
replace oportunas with nOportunas_tot for cod_munres = aArray_mun_list[n,1]
replace enc_oport with ( ( nOportunas_tot / nNotifics_tot ) * 100 ) for cod_munres = aArray_mun_list[n,1]
close

next

? "---------------------------------------------------------------------------"

copy file "c:\dnci\temp\dnci_index.dbf" to "c:\dnci\out\dnci_index.dbf"

set color to rb+/
? "O arquivo com os resultados estao na subpasta 'out'."
wait

return